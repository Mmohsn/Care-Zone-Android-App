package com.example.myapplication;

import androidx.annotation.NonNull;

public class AppointmentClass {
    String fullname , phone, email, department, date;

    public AppointmentClass() {
    }

    public AppointmentClass(String fullname, String phone, String email, String department, String date) {
        this.fullname = fullname;
        this.phone = phone;
        this.email = email;
        this.department = department;
        this.date = date;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @NonNull
    @Override
    public String toString() {
        return "Name:  "+fullname+"\nPhone:  "+phone+"\nEmail  :  "+email+"\nDepartment:  "+department+"\nDate: "+date;
    }
}
