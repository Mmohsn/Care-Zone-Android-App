package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Mainscreen extends AppCompatActivity {
    // Variables
    EditText name , id , pnum , disease, diagnoses  , docname , income , outcome ;
    Button btnsave , record , btnappointment,logoutt;
    Animation topanim1, bottomanim1;
    TextView text1 , text2;

    //==================================================================================
    // Firebase variables
    FirebaseDatabase database ;
    DatabaseReference reference;

    //==================================================================================
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainscreen);
//==================================================================================
        // Get the id For each element
        name = findViewById(R.id.name);
        id = findViewById(R.id.id);
        pnum = findViewById(R.id.pnum);
        disease = findViewById(R.id.disease);
        diagnoses = findViewById(R.id.diagnoses);
        docname = findViewById(R.id.docname);
        income = findViewById(R.id.income);
        outcome = findViewById(R.id.outcome);
        btnsave = findViewById(R.id.btnsave);
        record = findViewById(R.id.record);
        btnappointment = findViewById(R.id.btnappointment);
        logoutt = findViewById(R.id.logoutt);
//==================================================================================
        // Save the data to Firebase when Button Clicked
        btnsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            // to connect our data with firebase
            database = FirebaseDatabase.getInstance();
            reference = database.getReference("Patients");
            //Get All Values from Edit Text
             String Pname  = name.getText().toString();
             String Pid = id.getText().toString();
             String Pnumber = pnum.getText().toString();
             String Pdisease = disease.getText().toString();
             String Pdiagnoses = diagnoses.getText().toString();
             String doctorname = docname.getText().toString();
             String Pincome = income.getText().toString();
             String Poutcome = outcome.getText().toString();
             // Using the class to set the data
             HelperClass helperClass = new HelperClass(Pname ,Pid ,Pnumber ,Pdisease, Pdiagnoses,  doctorname,Pincome,Poutcome );
             // if fields empty show toast and don't save the data
             if (Pid.equals("") || Pnumber.equals ("")|| Pdiagnoses.equals("")) {
                 Toast.makeText(getApplicationContext(),"Please Enter Full Data", Toast.LENGTH_SHORT).show();
             }
             else {
                 //if fields not empty save the data and show toast
                 Toast.makeText(getApplicationContext(),"Patient Added Successfully", Toast.LENGTH_SHORT).show();
                 // to Get the value from the class into our firebase Sorted by ID in Child node
                 reference.child(Pid).setValue(helperClass);
             }


            }
        });
        // Logout Button to return back to Login screen and destroy Medical Record Screen
        logoutt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Mainscreen.this, Login.class);
                startActivity(intent);
                finish();
            }
        });


//==================================================================================
        // load animations
        topanim1 = AnimationUtils.loadAnimation(this,R.anim.top_animation1);
        bottomanim1 = AnimationUtils.loadAnimation(this,R.anim.bottom_animation1);
        //load text
        text1 = findViewById(R.id.text1);
        text2 = findViewById(R.id.text2);
        // Apply animation
        text1.setAnimation(topanim1);
        text2.setAnimation(topanim1);
//==================================================================================
        // Go to List View screen that contain Medical Records
        record.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Mainscreen.this,Customlist.class);
                startActivity(intent);
            }
        });
        // Go to Appoinetemnt screen
        btnappointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Mainscreen.this,Appointmentlist.class);
                startActivity(intent);
            }
        });



    }




}
