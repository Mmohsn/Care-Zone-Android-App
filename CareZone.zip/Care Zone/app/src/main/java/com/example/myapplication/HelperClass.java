package com.example.myapplication;


public class HelperClass {
    String name , id , pnum ,  disease ,diagnoses , docname , income , outcome ;

    public HelperClass() {
    }

    public HelperClass(String name, String id, String pnum, String disease,String diagnoses,  String docname, String income, String outcome) {
        this.name = name;
        this.id = id;
        this.pnum = pnum;
        this.disease = disease;
        this.diagnoses = diagnoses;
        this.docname = docname;
        this.income = income;
        this.outcome = outcome;
    }

    public HelperClass(String toString, String toString1, String toString2, String toString3, String toString4, String toString5) {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPnum() {
        return pnum;
    }

    public void setPnum(String pnum) {
        this.pnum = pnum;
    }

    public String getDisease() {
        return disease;
    }

    public void setDisease(String disease) {
        this.disease = disease;
    }

    public String getDiagnoses() {
        return diagnoses;
    }

    public void setDiagnoses(String diagnoses) {
        this.diagnoses = diagnoses;
    }



    public String getDocname() {
        return docname;
    }

    public void setDocname(String docname) {
        this.docname = docname;
    }

    public String getIncome() {
        return income;
    }

    public void setIncome(String income) {
        this.income = income;
    }

    public String getOutcome() {
        return outcome;
    }

    public void setOutcome(String outcome) {
        this.outcome = outcome;
    }

    @Override
    public String toString() {
        return "ID:  "+id+"\nName:  "+name+"\nDiagnoses  :  "+diagnoses+"\nDisease:  "+disease+"\nDate In Come:  "+income+"\nDate Out Come:  "+outcome;
    }
}
