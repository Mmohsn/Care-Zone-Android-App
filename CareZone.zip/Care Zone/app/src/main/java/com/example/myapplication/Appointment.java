package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Appointment extends AppCompatActivity {
    // Variables
    EditText namepatient, phonepatient,emailpatient,date;
    Button book,logout;
    Spinner department;
    FirebaseDatabase database ;
    DatabaseReference reference;
//==================================================================================
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment);
        //=============================================
        namepatient = findViewById(R.id.namepatient);
        phonepatient = findViewById(R.id.phonepatient);
        emailpatient = findViewById(R.id.emailpatient);
        department = findViewById(R.id.department);
        date = findViewById(R.id.date);
        book = findViewById(R.id.book);
        logout = findViewById(R.id.logout);
        //=============================================
        //Save data to firebase When Button Clicked
        book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                database = FirebaseDatabase.getInstance();
                reference = database.getReference("Appointments");
                // Get Data the data from Edit text
                String Pfullname = namepatient.getText().toString();
                String Pphone = phonepatient.getText().toString();
                String Pemail = emailpatient.getText().toString();
                String Pdepartment = department.getSelectedItem().toString();
                String Pdate = date.getText().toString();
//==================================================================================
                // Set the data in class
                AppointmentClass appointmentClass = new AppointmentClass(Pfullname,Pphone,Pemail,Pdepartment,Pdate);
                // if edit text empty show toast
                if ((Pfullname.isEmpty()) ||(Pphone.isEmpty()) ||(Pemail.isEmpty()) || (Pdepartment.isEmpty())||(Pdate.isEmpty())){
                    Toast.makeText(getApplicationContext(),"Please Enter Full Data", Toast.LENGTH_SHORT).show();
                }
                else{
                    // if edit text not empty, save the data from class into Child in firebase sorted by patients name
                    reference.child(Pfullname).setValue(appointmentClass);
                    Toast.makeText(getApplicationContext(),"Booking Success! We will connect you soon", Toast.LENGTH_LONG).show();
                }


            }
        });
        // Logout button to return to login screen
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Appointment.this,Login.class);
                startActivity(intent);
                finish();
            }
        });


    }
}
