package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class Appointmentlist extends AppCompatActivity {
    EditText namepatient, phonepatient,emailpatient,date;
    Button book;
    ListView applist;
    Spinner department;
    // Array List for appointments
    ArrayList<String> appointmentlist= new ArrayList<String>();
    // Array list for get the data for each patient
    ArrayList<String> appointment_keys = new ArrayList<String>();
    // Layout inflater to make list view response when button in another layout clicked
    LayoutInflater layoutInflater;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointmentlist);
        // using Layout inflater
        layoutInflater = (LayoutInflater)getSystemService(LAYOUT_INFLATER_SERVICE);
        // We want to access to Appointment activity to get the data in our list
        View main =layoutInflater.inflate(R.layout.activity_appointment,null,false);
        // Get each id for each object in Appointment Activity
        namepatient = main.findViewById(R.id.namepatient);
        phonepatient = main.findViewById(R.id.phonepatient);
        emailpatient = main.findViewById(R.id.emailpatient);
        department = main.findViewById(R.id.department);
        date = main.findViewById(R.id.date);
        book = main.findViewById(R.id.book);
        applist = findViewById(R.id.applist);


        // Calling Firebase
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        // we will store the data of appointment in Child called "Appointments" that will be our reference
        final DatabaseReference reference = database.getReference().child("Appointments");
        // then we will passing the text which is written in list view and passing appointment list to array adapter
        final ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(),R.layout.listtext,appointmentlist);
        // apply that adapter on the list
        applist.setAdapter(adapter);
        // When new child added to firebase
        reference.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded( DataSnapshot snapshot,  String previousChildName) {
                // Get the Key for each child
                appointment_keys.add(snapshot.getKey());
                // set the data from snapshot to our class
                AppointmentClass appointmentClass =snapshot.getValue(AppointmentClass.class);
                // add these data to list from the class
                appointmentlist.add(appointmentClass.toString());
                // update the data when new data added
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // if any error occur or there's no internet
                Toast.makeText(getApplicationContext(),"Failed", Toast.LENGTH_SHORT).show();

            }
        });
        // when any item clicked in the list show dialog to delete it
        applist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                // create the dialog
                AlertDialog.Builder builder = new AlertDialog.Builder(Appointmentlist.this);
                // set tha title and message
                builder.setTitle("Alert").setMessage("Do You want to delete this Patient?")
                        // When delete button Clicked
                        .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //*** Delete item from Firebase and the app ***
                        // Get the key of the child
                        reference.child(appointment_keys.get(position)).removeValue()
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                appointmentlist.remove(position);
                                adapter.notifyDataSetChanged();
                                Toast.makeText(getApplicationContext(),"Deleted", Toast.LENGTH_SHORT).show();

                            }
                        });
                    }
        }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                builder.create().show();

            }

        });



    }
}