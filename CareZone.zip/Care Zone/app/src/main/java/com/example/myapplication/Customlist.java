package com.example.myapplication;

import android.app.AlertDialog;
import android.app.Application;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.zip.Inflater;

public class Customlist extends AppCompatActivity {
    ListView list;
    // Creating Array List
    ArrayList<String> pateints = new ArrayList<String>();
    ArrayList<String> pateints_keys = new ArrayList<String>();
//=============================================================
    //DatabaseReference reference;
    EditText name , id , pnum , diagnoses , disease , docname , income , outcome;
    Button btnsave;
    LayoutInflater layoutInflater;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.listitem);
            // Layout in flater is function to allow us to access to objects in another layout
            layoutInflater = (LayoutInflater)getSystemService(LAYOUT_INFLATER_SERVICE);
            // Here we want to access to another layout to access to objects on it
            View main =layoutInflater.inflate(R.layout.activity_mainscreen,null,false);

            // these objects is in Medical Record screen
            btnsave = main.findViewById(R.id.btnsave);
            list = findViewById(R.id.list);
            id = main.findViewById(R.id.id);
            name = main.findViewById(R.id.name);
            disease = main.findViewById(R.id.disease);
            diagnoses = main.findViewById(R.id.diagnoses);
            income = main.findViewById(R.id.income);
            outcome = main.findViewById(R.id.outcome);


            FirebaseDatabase database = FirebaseDatabase.getInstance();
            // we want to store the data in the node called patients in firebase RealTime
            final DatabaseReference reference = database.getReference().child("Patients");

            /* Array Adapter converts an ArrayList of objects into View items loaded into the ListView container
            * here we passing the patients from array list and set the adapter on it
            */

            final ArrayAdapter <String> adapter = new ArrayAdapter<>(getApplicationContext(),R.layout.listtext,pateints);
            list.setAdapter(adapter);
            // Retrieve the data from firebase into list
            // our reference is patients node
            //addChildEventListener : used to receive events about changes in the child locations of our reference
            reference.addChildEventListener(new ChildEventListener() {
                @Override
                //when new data added
                public void onChildAdded( DataSnapshot snapshot, String previousChildName) {
                    // Get the Key for each child in node patients
                    // DataSnapshot instance contains data from a Firebase
                    // Keys ** Stands for the full data for each patient
                    pateints_keys.add(snapshot.getKey());
                    HelperClass helperClass = snapshot.getValue(HelperClass.class);
                    pateints.add(helperClass.toString());
                    //update our list with new data
                    adapter.notifyDataSetChanged();
                }

                @Override
                public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                }

                @Override
                public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                }

                @Override
                public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Toast.makeText(getApplicationContext(),"Failed", Toast.LENGTH_SHORT).show();

                }
            });

            // when item clicked show the dialog
            list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(final AdapterView<?> parent, View view, final int position, long id) {
                    // create the dialog
                    AlertDialog.Builder builder = new AlertDialog.Builder(Customlist.this);
                    //set the title and message
                    builder.setTitle("Alert").setMessage("Do You want to delete this Patient?")
                            // our positive button is delete button
                            .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                        @Override
                        // when delete button clicked
                        public void onClick(DialogInterface dialog, int which) {
                        //*** Delete item from Firebase and the list view in the application ***
                            // Get the key of the child
                            // position : the current position item in list
                            reference.child(pateints_keys.get(position)).removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                // if item deleted from firebase
                                // then delete it from list and show toast
                                public void onSuccess(Void aVoid) {
                                    pateints.remove(position);
                                    adapter.notifyDataSetChanged();
                                    Toast.makeText(getApplicationContext(),"Deleted", Toast.LENGTH_SHORT).show();

                                }
                            });

                        }
                        // cancel button to close the dialog and do nothing
                    }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }

                    });
                    // to make the dialog appear or call it
                    builder.create().show();

                }

            });



    }
}
